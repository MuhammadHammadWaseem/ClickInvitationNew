<?php
declare(strict_types = 1);

namespace BaconQrCode\Exception;

final class WriterException extends \RuntimeException implements ExceptionInterface
{
}
